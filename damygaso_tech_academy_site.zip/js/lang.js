// lang.js - simple client-side bilingual toggle (EN / SW)
const translations = {
  "en": {
    "home_title": "Empowering Innovators. Creating Job Creators.",
    "explore_courses": "Explore Courses",
    "courses_heading": "Courses we offer",
    "contact_heading": "Contact Us",
    "enroll": "Join Waitlist",
    "price": "250,000 TZS per course",
    "footer": "© DAMYGASO TECH ACADEMY",
    "about_title": "About DAMYGASO TECH ACADEMY",
    "instructors_title": "Meet the instructors"
  },
  "sw": {
    "home_title": "Kuwawezesha Wabunifu. Kuunda Wenye Kujiajiri.",
    "explore_courses": "Angalia Kozi",
    "courses_heading": "Kozi Tunaotoa",
    "contact_heading": "Wasiliana Nasi",
    "enroll": "Jiunge na Orodha",
    "price": "250,000 TZS kwa kozi",
    "footer": "© DAMYGASO TECH ACADEMY",
    "about_title": "Kuhusu DAMYGASO TECH ACADEMY",
    "instructors_title": "Kutana na walimu"
  }
};

function setLang(lang) {
  localStorage.setItem('damy_lang', lang);
  applyLang(lang);
}

function applyLang(lang) {
  const map = translations[lang] || translations['en'];
  document.querySelectorAll('[data-translate]').forEach(el=>{
    const key = el.getAttribute('data-translate');
    if(map[key]) el.textContent = map[key];
  });
  // toggle active button
  const btnEn = document.getElementById('btn-en');
  const btnSw = document.getElementById('btn-sw');
  if(btnEn) btnEn.classList.toggle('opacity-50', lang!=='en');
  if(btnSw) btnSw.classList.toggle('opacity-50', lang!=='sw');
}

document.addEventListener('DOMContentLoaded', ()=>{
  const saved = localStorage.getItem('damy_lang') || 'en';
  applyLang(saved);
  const be = document.getElementById('btn-en');
  const bs = document.getElementById('btn-sw');
  if(be) be.addEventListener('click', ()=> setLang('en'));
  if(bs) bs.addEventListener('click', ()=> setLang('sw'));
});